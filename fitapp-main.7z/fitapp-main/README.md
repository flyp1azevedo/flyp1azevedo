Para inicar o projeto siga os seguintes passos: 

- Na raiz do projeto execute: <code>$ npm i</code>

- Depois entre em <code>api/</code> e repita o comando.

- Ainda em <code>api/</code>, faça uma cópia do arquivo <code>.env.example</code>, removendo a extensão <code>.example</code>.

- Preencha <code>DATABASE_URL</code> com o nome do banco, por exemplo: <code>DATABASE_URL="file:./fitAppDb.db"</code>, e <code>JWT_SECRET</code> com um hash aleatório.

- Em seguida execute o seguinte comando: <code>$ npx prisma migrate dev</code>

- Use <code>$ npm run start:dev</code> para iniciar o backend.

- Voltando para a raiz do projeto, use <code>$ npm run start</code> para iniciar o frontend. Responda com <b>Y</b>, ou <b>enter</b> quando questionado.

- Acesse a aplicação em <code>http://localhost:3001/</code>

<b>Credenciais:</b>
> E-mail: admin@fitapp.com
> Senha: FITadmin.123
