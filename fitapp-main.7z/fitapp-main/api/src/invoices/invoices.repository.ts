import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.service';
import { CreateInvoiceDto } from './dto/create-invoice.dto';
import { Invoice } from '@prisma/client';
import { UpdateInvoiceDto } from './dto/update-invoice.dto';

@Injectable()
export class InvoicesRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(data: CreateInvoiceDto): Promise<Invoice> {
    const { peopleId, planId, dueDate, status } = data;
    const invoice = await this.prisma.invoice.create({
      data: {
        peopleId,
        planId,
        dueDate: new Date(dueDate),
        status,
      },
    });
    return this.prisma.invoice.findUnique({
      where: { id: invoice.id },
      include: { plan: true },
    });
  }

  async findAll(): Promise<Invoice[]> {
    return await this.prisma.invoice.findMany({
      include: {
        people: true,
        plan: true
      },
    });
  }

  async findOne(id: number): Promise<Invoice> {
    return await this.prisma.invoice.findFirst({
      where: { id },
      include: {
        people: true,
        plan: {
          include: {
            invoices: true,
          },
        },
      },
    });
  }

  async update(id: number, data: UpdateInvoiceDto): Promise<void> {
    const { planId, dueDate, status } = data;

    await this.prisma.invoice.update({
      where: { id },
      data: {
        ...(planId && { planId }),
        ...(dueDate && { dueDate: new Date(dueDate) }),
        ...(status && { status }),
      },
    });
  }

  async delete(id: number): Promise<void> {
    await this.prisma.invoice.delete({
      where: { id },
    });
  }
}
