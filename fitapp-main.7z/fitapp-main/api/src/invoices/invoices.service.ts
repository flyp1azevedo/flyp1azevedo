import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CreateInvoiceDto } from './dto/create-invoice.dto';
import { UpdateInvoiceDto } from './dto/update-invoice.dto';
import { InvoicesRepository } from './invoices.repository';

@Injectable()
export class InvoicesService {
  constructor(private readonly invoicesRepository: InvoicesRepository) {}

  async create(createInvoiceDto: CreateInvoiceDto) {
    try {
      const newInvoice = await this.invoicesRepository.create(createInvoiceDto);
      return { id: newInvoice.id, message: 'Fatura(s) criada com sucesso' };
    } catch (error) {
      console.log(error);
      throw new BadRequestException('Não foi possível criar a fatura!');
    }
  }

  async findAll() {
    return await this.invoicesRepository.findAll();
  }

  async findOne(id: number) {
    return await this.invoicesRepository.findOne(id);
  }

  async update(id: number, updateInvoiceDto: UpdateInvoiceDto) {
    const invoice = await this.invoicesRepository.findOne(id);
    if (!invoice) {
      throw new NotFoundException(`Fatura com id ${id} não encontrado!`);
    }
    try {
      await this.invoicesRepository.update(id, updateInvoiceDto);
      return { id: id, message: 'Fatura editada com sucesso' };
    } catch (error) {
      console.log(error);
      throw new BadRequestException('Algo de errado aconteceu!');
    }
  }

  async remove(id: number) {
    const invoice = await this.invoicesRepository.findOne(id);
    if (!invoice) {
      throw new NotFoundException(`Fatura com id ${id} não encontrado!`);
    }
    try {
      await this.invoicesRepository.delete(id);
      return { response: 'OK', message: 'Fatura excluída com sucesso' };
    } catch (error) {
      throw new BadRequestException('Algo de errado aconteceu!');
    }
  }
}
