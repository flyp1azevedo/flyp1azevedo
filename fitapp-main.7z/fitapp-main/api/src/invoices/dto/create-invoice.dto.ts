export class CreateInvoiceDto {
  peopleId: number;
  planId: number;
  dueDate: Date;
  status: string;
}
