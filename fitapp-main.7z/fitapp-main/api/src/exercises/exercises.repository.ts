import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.service';
import { CreateExerciseDto } from './dto/create-exercise.dto';
import { Exercise } from '@prisma/client';
import { UpdateExerciseDto } from './dto/update-exercise.dto';

@Injectable()
export class ExercisesRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(data: CreateExerciseDto): Promise<Exercise> {
    return await this.prisma.exercise.create({ data });
  }

  async findMany(): Promise<Exercise[]> {
    return await this.prisma.exercise.findMany();
  }

  async findOne(id: number): Promise<Exercise> {
    return await this.prisma.exercise.findFirst({
      where: { id },
    });
  }

  async update(id: number, data: UpdateExerciseDto): Promise<void> {
    await this.prisma.exercise.update({
      where: { id },
      data,
    });
  }

  async delete(id: number): Promise<void> {
    await this.prisma.exercise.delete({ where: { id } });
  }
}
