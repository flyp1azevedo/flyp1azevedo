export class CreateExerciseDto {
  id: number;
  name: string;
  description: string; //mudar para opcional
}
