import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CreateExerciseDto } from './dto/create-exercise.dto';
import { UpdateExerciseDto } from './dto/update-exercise.dto';
import { ExercisesRepository } from './exercises.repository';

@Injectable()
export class ExercisesService {
  constructor(private readonly exercisesRepository: ExercisesRepository) {}

  async create(createExerciseDto: CreateExerciseDto) {
    try {
      const newExercise =
        await this.exercisesRepository.create(createExerciseDto);
      return { id: newExercise.id, message: 'Exercício criado com sucesso' };
    } catch (error) {
      console.log(error);
      throw new BadRequestException('Não foi possível criar o exercício!');
    }
  }

  async findAll() {
    return this.exercisesRepository.findMany();
  }

  async findOne(id: number) {
    return this.exercisesRepository.findOne(id);
  }

  async update(id: number, updateExerciseDto: UpdateExerciseDto) {
    const exercise = await this.exercisesRepository.findOne(id);
    if (!exercise) {
      throw new NotFoundException(`Exercício com id ${id} não encontrado!`);
    }
    try {
      await this.exercisesRepository.update(id, updateExerciseDto);
      return { id: id, message: 'Exercício editado com sucesso' };
    } catch (error) {
      throw new BadRequestException('Algo de errado aconteceu!');
    }
  }

  async remove(id: number) {
    const exercise = await this.exercisesRepository.findOne(id);
    if (!exercise) {
      throw new NotFoundException(`Exercício com id ${id} não encontrado!`);
    }
    try {
      await this.exercisesRepository.delete(id);
      return { response: 'OK', message: 'Exercício excluído com sucesso' };
    } catch (error) {
      throw new BadRequestException('Algo de errado aconteceu!');
    }
  }
}
