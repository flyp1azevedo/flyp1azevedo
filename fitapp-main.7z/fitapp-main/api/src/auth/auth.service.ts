import {
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { AuthRepository } from './auth.repository';
import { JwtService } from '@nestjs/jwt';
import { LoginDto } from './dto/login.dto';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthService {
  constructor(
    private readonly authRepository: AuthRepository,
    private readonly jwtService: JwtService,
  ) {}

  async login(data: LoginDto): Promise<any> {
    const { email, password } = data;
    const user = await this.authRepository.findUserByEmail(email);

    if (!user) {
      throw new NotFoundException('Usuário não encontrado!');
    }

    if (user && (await bcrypt.compare(password, user.password))) {
      const payload = {
        email,
        sub: user.id,
        role: user.role,
        peopleId: user.peopleId,
      };
      return {
        access_token: this.jwtService.sign(payload),
      };
    }
    throw new UnauthorizedException('Credenciais Inválidas!');
  }
}
