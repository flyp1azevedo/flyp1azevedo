import { Injectable, NotFoundException } from '@nestjs/common';
import { User } from '@prisma/client';
import { PrismaService } from 'src/prisma/prisma.service';

@Injectable()
export class AuthRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findUserByEmail(email: string): Promise<User> {
    const userMail = await this.prisma.email.findFirst({
      where: { email },
    });

    if (!userMail) {
      throw new NotFoundException('Email não cadastrado na plataforma.');
    }

    return await this.prisma.user.findFirst({
      where: {
        emailId: userMail.id,
      },
    });
  }
}
