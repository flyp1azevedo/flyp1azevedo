export class CreatePlanDto {
  name: string;
  description?: string;
  value: number;
  serviceIds: number[];
  exerciseIds: number[];
}
