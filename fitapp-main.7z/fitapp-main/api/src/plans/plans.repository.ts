import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.service';
import { CreatePlanDto } from './dto/create-plan.dto';
import { Plan } from '@prisma/client';
import { UpdatePlanDto } from './dto/update-plan.dto';

@Injectable()
export class PlansRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(data: CreatePlanDto): Promise<Plan> {
    const { name, description, value, serviceIds, exerciseIds } = data;

    return await this.prisma.plan.create({
      data: {
        name,
        description,
        value,
        planServices: {
          create: serviceIds.map((id) => ({ service: { connect: { id } } })),
        },
        planExercises: {
          create: exerciseIds.map((id) => ({ exercise: { connect: { id } } })),
        },
      },
    });
  }

  async findMany(): Promise<Plan[]> {
    return await this.prisma.plan.findMany({
      include: {
        planServices: {
          include: {
            service: true,
          },
        },
        planExercises: {
          include: {
            exercise: {
              include: {
                workout: true,
              },
            },
          },
        },
      },
    });
  }

  async findOne(id: number): Promise<Plan> {
    return await this.prisma.plan.findFirst({
      where: { id },
      include: {
        planServices: {
          include: {
            service: true,
          },
        },
        planExercises: {
          include: {
            exercise: {
              include: {
                workout: true,
              },
            },
          },
        },
      },
    });
  }

  async update(id: number, data: UpdatePlanDto): Promise<void> {
    const { name, description, value, serviceIds, exerciseIds } = data;

    await this.prisma.plan.update({
      where: { id },
      data: {
        ...(name && { name }),
        ...(description && { description }),
        ...(value !== undefined && { value }),
      },
    });

    if (serviceIds) {
      await this.prisma.planService.deleteMany({ where: { planId: id } });
      await this.prisma.planService.createMany({
        data: serviceIds.map((serviceId) => ({
          planId: id,
          serviceId,
        })),
      });
    }

    if (exerciseIds) {
      await this.prisma.planExercise.deleteMany({ where: { planId: id } });
      await this.prisma.planExercise.createMany({
        data: exerciseIds.map((exerciseId) => ({
          planId: id,
          exerciseId,
        })),
      });
    }
  }

  async delete(id: number): Promise<void> {
    await this.prisma.plan.delete({ where: { id } });
  }
}
