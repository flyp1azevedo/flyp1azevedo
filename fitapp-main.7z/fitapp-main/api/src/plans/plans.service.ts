import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CreatePlanDto } from './dto/create-plan.dto';
import { PlansRepository } from './plans.repository';
import { UpdatePlanDto } from './dto/update-plan.dto';

@Injectable()
export class PlansService {
  constructor(private readonly plansRepository: PlansRepository) {}

  async create(createPlanDto: CreatePlanDto) {
    try {
      const newPlan = await this.plansRepository.create(createPlanDto);
      return { id: newPlan.id, message: 'Plano criado com sucesso' };
    } catch (error) {
      throw new BadRequestException('Algo de errado aconteceu! Erro: ' + error);
    }
  }

  async findAll() {
    return await this.plansRepository.findMany();
  }

  async findOne(id: number) {
    return await this.plansRepository.findOne(id);
  }

  async update(id: number, data: UpdatePlanDto) {
    const plan = await this.plansRepository.findOne(id);

    if (!plan) {
      throw new NotFoundException(`Plano com id ${id} não encontrado!`);
    }

    try {
      await this.plansRepository.update(id, data);
      return { response: 'OK', message: 'Plano atualizado com sucesso' };
    } catch (error) {
      throw new BadRequestException('Erro ao atualizar o plano: ' + error);
    }
  }

  async remove(id: number) {
    const plan = await this.plansRepository.findOne(id);
    if (!plan) {
      throw new NotFoundException(`Plano com id ${id} não encontrado!`);
    }
    try {
      await this.plansRepository.delete(id);
      return { response: 'OK', message: 'Plano excluído com sucesso' };
    } catch (error) {
      throw new BadRequestException('Erro ao excluir o plano: ' + error);
    }
  }
}
