import { Injectable } from '@nestjs/common';
import { People } from '@prisma/client';
import { PrismaService } from 'src/prisma/prisma.service';
import { CreatePersonDto } from './dto/create-person.dto';

@Injectable()
export class PeopleRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findOne(id: number): Promise<People> {
    return await this.prisma.people.findFirst({
      where: { id },
      include: {
        user: true,
        emails: true,
        phones: true,
        plan: true,
        registers: true,
        invoices: {
          select: {
            id: true,
            dueDate: true,
            status: true,
          },
        },
      },
    });
  }

  async findAll(): Promise<People[]> {
    return await this.prisma.people.findMany();
  }

  async create(data: CreatePersonDto): Promise<People> {
    const { firstName, lastName, cpf, birthDate, gender, email, phone, planId } = data;

    return this.prisma.people.create({
      data: {
        firstName,
        lastName,
        cpf,
        birthDate,
        gender,
        emails: {
          create: {
            email,
          },
        },
        phones: phone
          ? {
              create: {
                phone,
              },
            }
          : undefined,
        planId
      },
      include: {
        emails: {
          include: {
            user: true,
          },
        },
        phones: true,
      },
    });
  }

  async delete(id: number): Promise<void> {
    await this.prisma.email.deleteMany({ where: { peopleId: id } });
    await this.prisma.phone.deleteMany({ where: { peopleId: id } });
    await this.prisma.invoice.deleteMany({ where: { peopleId: id } });
    await this.prisma.register.deleteMany({ where: { peopleId: id } });

    await this.prisma.people.delete({
      where: { id },
    });
  }
}
