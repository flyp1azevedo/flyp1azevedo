import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CreatePersonDto } from './dto/create-person.dto';
import { PeopleRepository } from './people.repository';

@Injectable()
export class PeopleService {
  constructor(private readonly peopleRepository: PeopleRepository) {}

  async create(createPersonDto: CreatePersonDto) {
    try {
      const newPerson = await this.peopleRepository.create(createPersonDto);
      return { id: newPerson.id, message: 'Pessoa criada com sucesso' };
    } catch (error) {
      console.log(error);
      throw new BadRequestException('Algo de errado aconteceu!');
    }
  }

  async findAll() {
    return await this.peopleRepository.findAll();
  }

  async findOne(id: number) {
    return await this.peopleRepository.findOne(id);
  }

  async remove(id: number) {
    const person = await this.peopleRepository.findOne(id);
    if (!person) {
      throw new NotFoundException(`Pessoa com id ${id} não encontrada!`);
    }
    try {
      await this.peopleRepository.delete(id);
      return { response: 'OK', message: 'Pessoa deletada com sucesso!' };
    } catch (error) {
      throw new BadRequestException('Algo de Errado aconteceu!');
    }
  }
}
