export class CreatePersonDto {
  firstName: string;
  lastName: string;
  cpf: string;
  birthDate: Date;
  gender?: string;
  email: string;
  phone?: string;
  planId?: number
}
