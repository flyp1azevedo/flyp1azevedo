import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { UserRepository } from './user.repository';
import { CreateUserDto } from './dto/CreateUserDTO';
import { UpdateUserDto } from './dto/UpdateUserDTO';

@Injectable()
export class UserService {
  constructor(private readonly userRepository: UserRepository) {}

  async create(createUserDto: CreateUserDto) {
    try {
      const user = await this.userRepository.create(createUserDto);
      return { id: user.id, message: 'Usuário criado com sucesso.' };
    } catch (e) {
      throw new BadRequestException('Algo de errado aconteceu. Erro: ' + e);
    }
  }

  async findAll() {
    return await this.userRepository.findAll();
  }

  async findOne(id: number) {
    return await this.userRepository.findOne(id);
  }

  async update(id: number, data: UpdateUserDto) {
    const user = await this.userRepository.findOne(id);

    if (!user) {
      throw new NotFoundException(`Usuário com id ${id} não econtrado.`);
    }

    try {
      await this.userRepository.update(id, data);
      return { response: 'OK', message: 'Usuário atualizado com sucesso.' };
    } catch (e) {
      throw new BadRequestException('Erro ao atualizar usuário. Erro: ' + e);
    }
  }

  async delete(id: number) {
    const user = await this.userRepository.findOne(id);

    if (!user) {
      throw new NotFoundException(`Usuário com id ${id} não econtrado.`);
    }

    try {
      await this.userRepository.delete(id);
      return { response: 'OK', message: 'Usuário excluído com sucesso.' };
    } catch (e) {
      throw new BadRequestException('Erro ao excluir usuário. Erro: ' + e);
    }
  }
}
