import { Injectable } from '@nestjs/common';
import { User } from '@prisma/client';
import * as bcrypt from 'bcrypt';
import { PrismaService } from 'src/prisma/prisma.service';
import { CreateUserDto } from './dto/CreateUserDTO';
import { UpdateUserDto } from './dto/UpdateUserDTO';

@Injectable()
export class UserRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(): Promise<User[]> {
    return await this.prisma.user.findMany();
  }

  async findOne(id: number): Promise<User> {
    return await this.prisma.user.findFirst({
      where: { id },
      include: {
        email: true,
        people: true,
      },
    });
  }

  async create(data: CreateUserDto): Promise<User> {
    const { password, role, peopleId, emailId } = data;

    const hashedPassword = await bcrypt.hash(password, 10);

    return this.prisma.user.create({
      data: {
        password: hashedPassword,
        role: role ? role : 'USER',
        active: true,
        peopleId,
        emailId,
      },
    });
  }

  async update(id: number, data: UpdateUserDto): Promise<void> {
    const { password, role, active, peopleId, emailId } = data;

    await this.prisma.user.update({
      where: { id },
      data: {
        ...(password && { password }),
        ...(role && { role }),
        ...(active && { active }),
        ...(peopleId && { peopleId }),
        ...(emailId && { emailId }),
      },
    });
  }

  async delete(id: number): Promise<void> {
    await this.prisma.user.delete({ where: { id } });
  }
}
