export class CreateUserDto {
  password: string;
  role: string;
  active: boolean;
  peopleId: number;
  emailId: number;
}
