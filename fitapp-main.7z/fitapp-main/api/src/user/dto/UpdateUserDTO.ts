export class UpdateUserDto {
  password?: string;
  role?: string;
  active?: boolean;
  peopleId?: number;
  emailId?: number;
}
