import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.service';
import { CreateTrainingDto } from './dto/create-training.dto';
import { Training } from '@prisma/client';
import { UpdateTrainingDto } from './dto/update-training.dto';

@Injectable()
export class TrainingsRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(data: CreateTrainingDto): Promise<Training> {
    return await this.prisma.$transaction(async (prisma) => {
      // Cria o treinamento
      const training = await prisma.training.create({
        data: {
          in: new Date(data.in),
          out: new Date(data.out),
          date: new Date(data.date),
          people: { connect: { id: data.peopleId } },
        },
      });

      // Cria os workouts associados ao treinamento
      await Promise.all(
        data.exercises.map(async (exercise) => {
          await prisma.workout.create({
            data: {
              id: training.id,
              exerciseId: exercise.id,
              repetitions: exercise.repetitions,
              load: exercise.load,
              series: exercise.series,
            },
          });
        }),
      );

      return training;
    });
  }

  async findAll(): Promise<Training[]> {
    return await this.prisma.training.findMany({
      include: {
        people: true,
        workouts: {
          include: {
            exercise: true,
          },
        },
      },
    });
  }

  async findOne(id: number): Promise<Training> {
    return await this.prisma.training.findUnique({
      where: { id },
      include: {
        people: true,
        workouts: {
          include: {
            exercise: true,
          },
        },
      },
    });
  }

  async update(id: number, data: UpdateTrainingDto): Promise<void> {
    const { exercises, ...trainingData } = data;

    await this.prisma.$transaction(async (prisma) => {
      await prisma.training.update({
        where: { id },
        data: {
          in: trainingData.in ? new Date(trainingData.in) : undefined,
          out: trainingData.out ? new Date(trainingData.out) : undefined,
          date: trainingData.date ? new Date(trainingData.date) : undefined,
          people: trainingData.peopleId
            ? { connect: { id: trainingData.peopleId } }
            : undefined,
        },
      });

      if (exercises) {
        await prisma.workout.deleteMany({
          where: { id },
        });

        await Promise.all(
          exercises.map(async (exercise) => {
            await prisma.workout.create({
              data: {
                exerciseId: exercise.id,
                id,
                repetitions: exercise.repetitions,
                load: exercise.load,
                series: exercise.series,
              },
            });
          }),
        );
      }
    });
  }

  async delete(id: number): Promise<void> {
    await this.prisma.$transaction(async (prisma) => {
      await prisma.workout.deleteMany({
        where: { id },
      });

      await prisma.training.delete({ where: { id } });
    });
  }
}
