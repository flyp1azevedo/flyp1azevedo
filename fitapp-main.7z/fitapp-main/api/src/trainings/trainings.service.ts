import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CreateTrainingDto } from './dto/create-training.dto';
import { UpdateTrainingDto } from './dto/update-training.dto';
import { TrainingsRepository } from './trainings.repository';

@Injectable()
export class TrainingsService {
  constructor(private readonly trainingsRepository: TrainingsRepository) {}
  async create(createTrainingDto: CreateTrainingDto) {
    try {
      const newTraining =
        await this.trainingsRepository.create(createTrainingDto);
      return { id: newTraining.id, message: 'Treino criado com sucesso' };
    } catch (error) {
      console.log(error);
      throw new BadRequestException('Não foi possível criar o treino!');
    }
  }

  async findAll() {
    return this.trainingsRepository.findAll();
  }

  async findOne(id: number) {
    return this.trainingsRepository.findOne(id);
  }

  async update(id: number, updateTrainingDto: UpdateTrainingDto) {
    const training = await this.trainingsRepository.findOne(id);
    if (!training) {
      throw new NotFoundException(`Treino com id ${id} não encontrado!`);
    }
    try {
      await this.trainingsRepository.update(id, updateTrainingDto);
      return { id: id, message: 'Treino editado com sucesso' };
    } catch (error) {
      console.log(error);
      throw new BadRequestException('Algo de errado aconteceu!');
    }
  }

  async remove(id: number) {
    const training = await this.trainingsRepository.findOne(id);
    if (!training) {
      throw new NotFoundException(`Treino com id ${id} não encontrado!`);
    }
    try {
      await this.trainingsRepository.delete(id);
      return { response: 'OK', message: 'Treino excluído com sucesso' };
    } catch (error) {
      throw new BadRequestException('Algo de errado aconteceu!');
    }
  }
}
