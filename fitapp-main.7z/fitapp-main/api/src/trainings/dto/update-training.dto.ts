export class UpdateTrainingDto {
  in?: string;
  out?: string;
  date?: string;
  peopleId?: number;
  exercises?: {
    id: number; // ID do exercício
    repetitions: number;
    load: number;
    series: number;
  }[];
}
