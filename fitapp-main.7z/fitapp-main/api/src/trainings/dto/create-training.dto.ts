export class CreateTrainingDto {
  in: string; // Horário de entrada
  out: string; // Horário de saída
  date: string; // Data do treinamento
  peopleId: number; // ID da pessoa associada
  exercises: {
    id: number; // ID do exercício
    repetitions: number; // Repetições
    load: number; // Carga
    series: number; // Séries
  }[];
}
