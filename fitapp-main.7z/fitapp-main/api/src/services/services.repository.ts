import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.service';
import { CreateServiceDto } from './dto/create-service.dto';
import { UpdateServiceDto } from './dto/update-service.dto';
import { Service } from '@prisma/client';

@Injectable()
export class ServicesRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(data: CreateServiceDto): Promise<Service> {
    return await this.prisma.service.create({ data });
  }

  async findAll(): Promise<Service[]> {
    return await this.prisma.service.findMany();
  }

  async findOne(id: number): Promise<Service> {
    return await this.prisma.service.findFirst({
      where: { id },
    });
  }

  async update(id: number, data: UpdateServiceDto): Promise<void> {
    await this.prisma.service.update({
      where: { id },
      data,
    });
  }

  async delete(id: number): Promise<void> {
    await this.prisma.service.delete({
      where: { id },
    });
  }
}
