export class CreateServiceDto {
  name: string;
  description: string; //mudar para opcional
}
