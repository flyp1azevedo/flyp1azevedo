import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CreateServiceDto } from './dto/create-service.dto';
import { UpdateServiceDto } from './dto/update-service.dto';
import { ServicesRepository } from './services.repository';

@Injectable()
export class ServicesService {
  constructor(private readonly servicesRepository: ServicesRepository) {}

  async create(createServiceDto: CreateServiceDto) {
    try {
      const newService = await this.servicesRepository.create(createServiceDto);
      return { id: newService.id, message: 'Serviço criado com sucesso' };
    } catch {
      throw new BadRequestException('Não foi possível criar o serviço!');
    }
  }

  async findAll() {
    return await this.servicesRepository.findAll();
  }

  async findOne(id: number) {
    return await this.servicesRepository.findOne(id);
  }

  async update(id: number, updateServiceDto: UpdateServiceDto) {
    const service = await this.servicesRepository.findOne(id);
    if (!service) {
      throw new NotFoundException(`Serviço com id ${id} não encontrado!`);
    }
    try {
      await this.servicesRepository.update(id, updateServiceDto);
      return { id: id, message: 'Serviço editado com sucesso' };
    } catch (error) {
      throw new BadRequestException('Algo de errado aconteceu!');
    }
  }

  async remove(id: number) {
    const service = await this.servicesRepository.findOne(id);
    if (!service) {
      throw new NotFoundException(`Serviço com id ${id} não encontrado!`);
    }
    try {
      await this.servicesRepository.delete(id);
      return { response: 'OK', message: 'Serviço excluido com sucesso' };
    } catch (error) {
      throw new BadRequestException('Algo de errado aconteceu!');
    }
  }
}
