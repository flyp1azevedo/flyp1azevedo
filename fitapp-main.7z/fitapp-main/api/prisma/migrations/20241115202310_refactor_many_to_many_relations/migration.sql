/*
  Warnings:

  - You are about to drop the `_plans_exercises` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `_plans_services` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the column `plansId` on the `services` table. All the data in the column will be lost.

*/
-- DropIndex
DROP INDEX "_plans_exercises_B_index";

-- DropIndex
DROP INDEX "_plans_exercises_AB_unique";

-- DropIndex
DROP INDEX "_plans_services_B_index";

-- DropIndex
DROP INDEX "_plans_services_AB_unique";

-- DropTable
PRAGMA foreign_keys=off;
DROP TABLE "_plans_exercises";
PRAGMA foreign_keys=on;

-- DropTable
PRAGMA foreign_keys=off;
DROP TABLE "_plans_services";
PRAGMA foreign_keys=on;

-- CreateTable
CREATE TABLE "plans_services" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "planId" INTEGER NOT NULL,
    "serviceId" INTEGER NOT NULL,
    CONSTRAINT "plans_services_planId_fkey" FOREIGN KEY ("planId") REFERENCES "plans" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "plans_services_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "services" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "plans_exercises" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "planId" INTEGER NOT NULL,
    "exerciseId" INTEGER NOT NULL,
    CONSTRAINT "plans_exercises_planId_fkey" FOREIGN KEY ("planId") REFERENCES "plans" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "plans_exercises_exerciseId_fkey" FOREIGN KEY ("exerciseId") REFERENCES "exercises" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_services" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "description" TEXT
);
INSERT INTO "new_services" ("description", "id", "name") SELECT "description", "id", "name" FROM "services";
DROP TABLE "services";
ALTER TABLE "new_services" RENAME TO "services";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;

-- CreateIndex
CREATE UNIQUE INDEX "plans_services_planId_serviceId_key" ON "plans_services"("planId", "serviceId");

-- CreateIndex
CREATE UNIQUE INDEX "plans_exercises_planId_exerciseId_key" ON "plans_exercises"("planId", "exerciseId");
