/*
  Warnings:

  - You are about to drop the `invoice_plan` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `people` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `people_plans` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `plan_services` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `register` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `training` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `workout_plans` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `workout_training` table. If the table is not empty, all the data it contains will be lost.
  - A unique constraint covering the columns `[name]` on the table `plans` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `planId` to the `invoices` table without a default value. This is not possible if the table is not empty.
  - Made the column `peopleId` on table `users` required. This step will fail if there are existing NULL values in that column.

*/
-- DropIndex
DROP INDEX "people_cpf_key";

-- AlterTable
ALTER TABLE "services" ADD COLUMN "plansId" INTEGER;

-- DropTable
PRAGMA foreign_keys=off;
DROP TABLE "invoice_plan";
PRAGMA foreign_keys=on;

-- DropTable
PRAGMA foreign_keys=off;
DROP TABLE "people";
PRAGMA foreign_keys=on;

-- DropTable
PRAGMA foreign_keys=off;
DROP TABLE "people_plans";
PRAGMA foreign_keys=on;

-- DropTable
PRAGMA foreign_keys=off;
DROP TABLE "plan_services";
PRAGMA foreign_keys=on;

-- DropTable
PRAGMA foreign_keys=off;
DROP TABLE "register";
PRAGMA foreign_keys=on;

-- DropTable
PRAGMA foreign_keys=off;
DROP TABLE "training";
PRAGMA foreign_keys=on;

-- DropTable
PRAGMA foreign_keys=off;
DROP TABLE "workout_plans";
PRAGMA foreign_keys=on;

-- DropTable
PRAGMA foreign_keys=off;
DROP TABLE "workout_training";
PRAGMA foreign_keys=on;

-- CreateTable
CREATE TABLE "peoples" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "cpf" TEXT NOT NULL,
    "birthDate" DATETIME,
    "gender" TEXT,
    "planId" INTEGER,
    CONSTRAINT "peoples_planId_fkey" FOREIGN KEY ("planId") REFERENCES "plans" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "registers" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "date" DATETIME NOT NULL,
    "peopleId" INTEGER NOT NULL,
    "height" REAL NOT NULL,
    "weight" REAL NOT NULL,
    "IMC" REAL NOT NULL,
    "activityLevel" TEXT NOT NULL,
    "observations" TEXT NOT NULL,
    CONSTRAINT "registers_peopleId_fkey" FOREIGN KEY ("peopleId") REFERENCES "peoples" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "trainings" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "peopleId" INTEGER NOT NULL,
    "in" DATETIME NOT NULL,
    "out" DATETIME NOT NULL,
    "date" DATETIME NOT NULL,
    CONSTRAINT "trainings_peopleId_fkey" FOREIGN KEY ("peopleId") REFERENCES "peoples" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "_plans_services" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL,
    CONSTRAINT "_plans_services_A_fkey" FOREIGN KEY ("A") REFERENCES "plans" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "_plans_services_B_fkey" FOREIGN KEY ("B") REFERENCES "services" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "_plans_exercises" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL,
    CONSTRAINT "_plans_exercises_A_fkey" FOREIGN KEY ("A") REFERENCES "exercises" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "_plans_exercises_B_fkey" FOREIGN KEY ("B") REFERENCES "plans" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_emails" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "email" TEXT NOT NULL,
    "peopleId" INTEGER NOT NULL,
    CONSTRAINT "emails_peopleId_fkey" FOREIGN KEY ("peopleId") REFERENCES "peoples" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_emails" ("email", "id", "peopleId") SELECT "email", "id", "peopleId" FROM "emails";
DROP TABLE "emails";
ALTER TABLE "new_emails" RENAME TO "emails";
CREATE UNIQUE INDEX "emails_email_key" ON "emails"("email");
CREATE TABLE "new_invoices" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "peopleId" INTEGER NOT NULL,
    "planId" INTEGER NOT NULL,
    "dueDate" DATETIME NOT NULL,
    "status" TEXT,
    CONSTRAINT "invoices_peopleId_fkey" FOREIGN KEY ("peopleId") REFERENCES "peoples" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "invoices_planId_fkey" FOREIGN KEY ("planId") REFERENCES "plans" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_invoices" ("dueDate", "id", "peopleId", "status") SELECT "dueDate", "id", "peopleId", "status" FROM "invoices";
DROP TABLE "invoices";
ALTER TABLE "new_invoices" RENAME TO "invoices";
CREATE TABLE "new_phones" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "phone" TEXT NOT NULL,
    "peopleId" INTEGER NOT NULL,
    CONSTRAINT "phones_peopleId_fkey" FOREIGN KEY ("peopleId") REFERENCES "peoples" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_phones" ("id", "peopleId", "phone") SELECT "id", "peopleId", "phone" FROM "phones";
DROP TABLE "phones";
ALTER TABLE "new_phones" RENAME TO "phones";
CREATE UNIQUE INDEX "phones_phone_key" ON "phones"("phone");
CREATE TABLE "new_users" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "emailId" INTEGER NOT NULL,
    "peopleId" INTEGER NOT NULL,
    "password" TEXT NOT NULL,
    "role" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL,
    CONSTRAINT "users_emailId_fkey" FOREIGN KEY ("emailId") REFERENCES "emails" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "users_peopleId_fkey" FOREIGN KEY ("peopleId") REFERENCES "peoples" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_users" ("active", "emailId", "id", "password", "peopleId", "role") SELECT "active", "emailId", "id", "password", "peopleId", "role" FROM "users";
DROP TABLE "users";
ALTER TABLE "new_users" RENAME TO "users";
CREATE UNIQUE INDEX "users_emailId_key" ON "users"("emailId");
CREATE UNIQUE INDEX "users_peopleId_key" ON "users"("peopleId");
CREATE TABLE "new_workouts" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "exerciseId" INTEGER NOT NULL,
    "repetitions" INTEGER NOT NULL,
    "load" INTEGER NOT NULL,
    "series" INTEGER NOT NULL,
    CONSTRAINT "workouts_exerciseId_fkey" FOREIGN KEY ("exerciseId") REFERENCES "exercises" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_workouts" ("exerciseId", "id", "load", "repetitions", "series") SELECT "exerciseId", "id", "load", "repetitions", "series" FROM "workouts";
DROP TABLE "workouts";
ALTER TABLE "new_workouts" RENAME TO "workouts";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;

-- CreateIndex
CREATE UNIQUE INDEX "peoples_cpf_key" ON "peoples"("cpf");

-- CreateIndex
CREATE UNIQUE INDEX "_plans_services_AB_unique" ON "_plans_services"("A", "B");

-- CreateIndex
CREATE INDEX "_plans_services_B_index" ON "_plans_services"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_plans_exercises_AB_unique" ON "_plans_exercises"("A", "B");

-- CreateIndex
CREATE INDEX "_plans_exercises_B_index" ON "_plans_exercises"("B");

-- CreateIndex
CREATE UNIQUE INDEX "plans_name_key" ON "plans"("name");
