import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function seed() {
  const birthDate = new Date(2024, 10, 15);
  const password = await bcrypt.hash('FITadmin.123', 10);

  const people = await prisma.people.create({
    data: {
      firstName: 'FitApp',
      lastName: 'Admin',
      cpf: '11.111.111-11',
      birthDate: birthDate,
      gender: 'MASC',
    },
  });

  await prisma.phone.create({
    data: {
      phone: '(00) 00000-0000',
      peopleId: people.id,
    },
  });

  const email = await prisma.email.create({
    data: {
      email: 'admin@fitapp.com',
      peopleId: people.id,
    },
  });

  await prisma.user.create({
    data: {
      password: password,
      peopleId: people.id,
      emailId: email.id,
      role: 'ADMIN',
      active: true,
    },
  });
}

seed()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
