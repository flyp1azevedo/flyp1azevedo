import { useAccessToken } from "./../hooks/useAccessToken";
import { useEffect, useState } from "react";
import { AuthContext } from "./../contexts/AuthContext";
import { useHistory } from "react-router-dom";
import { api } from "services/api";
import { useGetPeoples } from "../hooks/usePeoples";

export const AuthProvider = ({ children }) => {
  const { getAccessToken } = useAccessToken();
  const [alreadyExists, setAlreadyExists] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const token = getAccessToken();
  const history = useHistory();
  const { isSuccess, isFetching } = useGetPeoples({ enabled: alreadyExists });

  useEffect(() => {
    if (token) {
      api.defaults.headers.common["Authorization"] = `Bearer ${token}`;
      setAlreadyExists(!!token);
    }
  }, []);

  useEffect(() => {
    if (!isFetching) {
      if (isSuccess) {
        setIsAuthenticated(true);
        history.push("/admin/dashboard");
        return;
      }

      history.replace("/auth/signin");
      setIsAuthenticated(false);
    }
  }, [isSuccess]);

  return (
    <AuthContext.Provider value={{ isAuthenticated }}>
      {children}
    </AuthContext.Provider>
  );
};
