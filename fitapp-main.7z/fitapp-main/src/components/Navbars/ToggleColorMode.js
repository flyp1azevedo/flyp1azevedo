import { MoonIcon, SunIcon } from "@chakra-ui/icons";
import { useColorMode } from "@chakra-ui/system";

const ToggleColorMode = ({ color }) => {
  const { colorMode, toggleColorMode } = useColorMode();

  return (
    <>
      {colorMode === "light" ? (
        <MoonIcon
          cursor="pointer"
          ms={{ base: "16px", xl: "0px" }}
          me="16px"
          onClick={toggleColorMode}
          color={color}
          w="18px"
          h="18px"
        />
      ) : (
        <SunIcon
          cursor="pointer"
          ms={{ base: "16px", xl: "0px" }}
          me="16px"
          onClick={toggleColorMode}
          color={color}
          w="18px"
          h="18px"
        />
      )}
    </>
  );
};

export default ToggleColorMode;
