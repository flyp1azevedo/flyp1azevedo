export default function formatCPF(cpf) {
  const cleanedCPF = cpf.replace(/\D/g, '');

  return cleanedCPF.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
}
