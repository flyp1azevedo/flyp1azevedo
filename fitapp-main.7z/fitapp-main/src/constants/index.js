export const KEYS = {
  ACCESS_TOKEN: "@ACCESS_TOKEN",
  REMEMBER_ME: "@REMEMBER_ME",
  PEOPLES: "peoples",
  PLANS: "plans",
  EXERCISES: "exercises",
  SERVICES: "services",
};
