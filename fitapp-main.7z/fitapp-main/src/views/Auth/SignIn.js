import React from "react";
// Chakra imports
import {
  Box,
  Flex,
  Button,
  FormControl,
  FormLabel,
  Heading,
  Input,
  Link,
  Switch,
  Text,
  useColorModeValue,
} from "@chakra-ui/react";
// Assets
import signInImage from "assets/img/fit-app-login-page-image.jpg";
import { useForm } from "react-hook-form";
import { api } from "services/api";
import { useAccessToken } from "../../hooks/useAccessToken";
import { useRememberMe } from "../../hooks/useRememberMe";
import { useHistory } from "react-router-dom";

function SignIn() {
  const history = useHistory();
  const { setAccessToken } = useAccessToken();
  const { setRememberMe } = useRememberMe();
  const { register, handleSubmit } = useForm();

  const onSubmit = async (data) => {
    try {
      const response = await api.post("/auth/login", data);
      setAccessToken(response.data.access_token);
      history.replace("/admin/dashboard");
    } catch (error) {
      console.error("Error login", error);
    }
  };

  const handleChangeRememberMe = (event) => {
    setRememberMe(event.target.checked);
  };

  const titleColor = useColorModeValue("red.500", "red.200");
  const textColor = useColorModeValue("gray.400", "white");

  return (
    <Flex position="relative" mb="40px">
      <Flex
        h={{ sm: "initial", md: "75vh", lg: "85vh" }}
        w="100%"
        maxW="1044px"
        mx="auto"
        justifyContent="space-between"
        mb="30px"
        pt={{ sm: "100px", md: "0px" }}
      >
        <Flex
          alignItems="center"
          justifyContent="start"
          style={{ userSelect: "none" }}
          w={{ base: "100%", md: "50%", lg: "42%" }}
        >
          <Flex
            direction="column"
            w="100%"
            background="transparent"
            p="48px"
            mt={{ md: "150px", lg: "80px" }}
            as="form"
            onSubmit={handleSubmit(onSubmit)}
          >
            <Heading color={titleColor} fontSize="32px" mb="10px">
              Bem-vindo de volta
            </Heading>
            <Text
              mb="36px"
              ms="4px"
              color={textColor}
              fontWeight="bold"
              fontSize="14px"
            >
              Use seu email e senha para entrar
            </Text>
            <FormControl>
              <FormLabel ms="4px" fontSize="sm" fontWeight="normal">
                Email
              </FormLabel>
              <Input
                borderRadius="15px"
                mb="24px"
                fontSize="sm"
                type="text"
                placeholder="Seu endereço de email"
                size="lg"
                {...register("email")}
              />
              <FormLabel ms="4px" fontSize="sm" fontWeight="normal">
                Senha
              </FormLabel>
              <Input
                borderRadius="15px"
                mb="36px"
                fontSize="sm"
                type="password"
                placeholder="Sua senha"
                size="lg"
                {...register("password")}
              />
              <FormControl display="flex" alignItems="center">
                <Switch
                  id="remember-login"
                  colorScheme="red"
                  me="10px"
                  onChange={handleChangeRememberMe}
                />
                <FormLabel
                  htmlFor="remember-login"
                  mb="0"
                  ms="1"
                  fontWeight="normal"
                >
                  Lembrar-me
                </FormLabel>
              </FormControl>
              <Button
                fontSize="10px"
                type="submit"
                bg="red.500"
                w="100%"
                h="45"
                mb="20px"
                color="white"
                mt="20px"
                _hover={{
                  bg: "red.200",
                }}
                _active={{
                  bg: "red.400",
                }}
              >
                Entrar
              </Button>
            </FormControl>
          </Flex>
        </Flex>
        <Box
          display={{ base: "none", md: "block" }}
          overflowX="hidden"
          h="100%"
          w="40vw"
          position="absolute"
          right="0px"
        >
          <Box
            bgImage={signInImage}
            w="100%"
            h="100%"
            bgSize="cover"
            bgPosition="50%"
            position="absolute"
            borderBottomLeftRadius="20px"
          ></Box>
        </Box>
      </Flex>
    </Flex>
  );
}

export default SignIn;
