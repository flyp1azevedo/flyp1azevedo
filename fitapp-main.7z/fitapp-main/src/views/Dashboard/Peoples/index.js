// Chakra imports
import { Flex, CircularProgress } from "@chakra-ui/react";
import React, { useEffect } from "react";
import Users from "./components/Users";
import { useGetPeoples } from "hooks/usePeoples";

function Peoples() {
  const { data, isLoading } = useGetPeoples();

  useEffect(() => {
    console.log(data.data);
  }, [data]);

  if (isLoading) {
    return (
      <Flex
        id="loading"
        sx={{ height: "80vh", width: "100%" }}
        justifyContent="center"
        alignItems="center"
      >
        <CircularProgress isIndeterminate color="red.500" size={100} />
      </Flex>
    );
  }

  return (
    <Flex direction="column" pt={{ base: "120px", md: "75px" }}>
      <Users
        title={"Usuários"}
        captions={["Nome", "CPF", "Nascimento"]}
        data={data.data}
      />
    </Flex>
  );
}

export default Peoples;
