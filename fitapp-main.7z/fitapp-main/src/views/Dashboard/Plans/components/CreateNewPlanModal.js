import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  FormControl,
  FormLabel,
  Input,
  Button,
  InputGroup,
  InputLeftAddon,
  FormErrorMessage,
  useToast,
} from "@chakra-ui/react";
import { useCreatePlan, useUpdatePlan } from "hooks/usePlans";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { getServices } from "services/api";
import { getExercises } from "services/api";
import Select from "react-select";

const CreateNewPlanModal = ({
  isOpen,
  setIsOpen,
  reloadPlans,
  planData = null,
  isEditMode = false,
}) => {
  const {
    handleSubmit,
    register,
    reset,
    clearErrors,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm();
  const [loadingData, setLoadingData] = useState();
  const [selectedServices, setSelectedServices] = useState([]);
  const [selectedExercises, setSelectedExercises] = useState([]);
  const [servicesOptions, setServicesOptions] = useState([]);
  const [exercisesOptions, setExercisesOptions] = useState([]);

  const toast = useToast();

  const getServicesData = async () => {
    const data = await getServices();
    if (data) {
      setServicesOptions(
        data.data.map((service) => ({
          value: service.id,
          label: service.name,
        }))
      );
    }
  };

  const getExercisesData = async () => {
    const data = await getExercises();
    if (data) {
      setExercisesOptions(
        data.data.map((exercise) => ({
          value: exercise.id,
          label: exercise.name,
        }))
      );
    }
  };

  useEffect(() => {
    if (isOpen) {
      setLoadingData(true);

      getServicesData();
      getExercisesData();

      if (isEditMode && planData) {
        setValue("name", planData.name);
        setValue("description", planData.description);
        setValue("value", planData.value);

        setSelectedServices(
          planData.planServices.map((item) => ({
            value: item.serviceId,
            label: item.service.name,
          }))
        );
        setSelectedExercises(
          planData.planExercises.map((item) => ({
            value: item.exerciseId,
            label: item.exercise.name,
          }))
        );
      } else if (!isEditMode) {
        reset({ name: "", description: "", value: "" });
        setSelectedServices([]);
        setSelectedExercises([]);
      }
      setLoadingData(false);
    }
  }, [isOpen, isEditMode, planData, setValue, reset]);

  const onSubmit = async (values) => {
    const payload = {
      ...values,
      serviceIds: selectedServices.map((service) => service.value),
      exerciseIds: selectedExercises.map((exercise) => exercise.value),
    };

    if (isEditMode) {
      updatePlan.mutate({ id: planData.id, data: payload });
    } else {
      createPlan.mutate({ data: payload });
    }
  };

  const createPlan = useCreatePlan({
    onSuccess: () => {
      toast({
        title: "Plano criado com sucesso!",
        status: "success",
        duration: 3000,
        isClosable: true,
        position: "bottom-right",
      });
      reloadPlans();
      setIsOpen(false);
      reset();
    },
    onError: (error) => {
      toast({
        title: "Erro ao criar plano.",
        description: error.message || "Tente novamente mais tarde.",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom-right",
      });
    },
  });

  const updatePlan = useUpdatePlan({
    onSuccess: () => {
      toast({
        title: "Plano atualizado com sucesso!",
        status: "success",
        duration: 3000,
        isClosable: true,
        position: "bottom-right",
      });
      reloadPlans();
      setIsOpen(false);
      reset();
    },
    onError: (error) => {
      toast({
        title: "Erro ao atualizar plano.",
        description: error.message || "Tente novamente mais tarde.",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom-right",
      });
    },
  });

  const onClose = () => {
    clearErrors();
    setIsOpen(false);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>
          {isEditMode ? "Editar Plano" : "Adicionar novo Plano"}
        </ModalHeader>
        <ModalCloseButton onClick={onClose} />
        <form onSubmit={handleSubmit(onSubmit)}>
          <ModalBody pb={6}>
            <FormControl isInvalid={errors.name}>
              <FormLabel htmlFor="name">Nome</FormLabel>
              <Input
                id="name"
                placeholder="Nome do plano"
                {...register("name", {
                  required: "Este campo é obrigatório",
                  minLength: {
                    value: 4,
                    message: "O nome precisa ter mais que 4 caracteres",
                  },
                })}
              />
              <FormErrorMessage>
                {errors.name && errors.name.message}
              </FormErrorMessage>
            </FormControl>
            <FormControl mt={4} isInvalid={errors.description}>
              <FormLabel htmlFor="description">Descrição</FormLabel>
              <Input
                id="description"
                placeholder="Descreva o seu plano"
                {...register("description")}
              />
              <FormErrorMessage>
                {errors.description && errors.description.message}
              </FormErrorMessage>
            </FormControl>
            <FormControl mt={4} isInvalid={errors.value}>
              <FormLabel htmlFor="value">Preço</FormLabel>
              <InputGroup>
                <InputLeftAddon children="R$" />
                <Input
                  id="value"
                  placeholder="Descreva o seu plano"
                  type="number"
                  {...register("value", {
                    required: "Este campo é obrigatório",
                    valueAsNumber: true,
                    min: {
                      value: 1,
                      message: "O valor precisa ser no mínimo R$1,00",
                    },
                  })}
                />
              </InputGroup>
              <FormErrorMessage>
                {errors.value && errors.value.message}
              </FormErrorMessage>
            </FormControl>
            <FormControl mt={4} isDisabled={loadingData}>
              <FormLabel>Serviços</FormLabel>
              <Select
                isMulti
                isSearchable
                isLoading={loadingData}
                loadingText="Carregando..."
                options={servicesOptions}
                value={selectedServices}
                onChange={(selected) => setSelectedServices(selected)}
                placeholder="Selecione os serviços"
              />
            </FormControl>
            <FormControl mt={4} isDisabled={loadingData}>
              <FormLabel>Exercícios</FormLabel>
              <Select
                isMulti
                isSearchable
                isLoading={loadingData}
                loadingText="Carregando..."
                options={exercisesOptions}
                value={selectedExercises}
                onChange={(selected) => setSelectedExercises(selected)}
                placeholder="Selecione os exercícios"
              />
            </FormControl>
          </ModalBody>
          <ModalFooter>
            <Button
              type="submit"
              isLoading={isSubmitting}
              loadingText={isEditMode ? "Salvando" : "Adicionando"}
              mr={3}
              variant="solid"
              bgColor="red.500"
              _hover={{ bgColor: "red.600" }}
            >
              {isEditMode ? "Salvar Alterações" : "Adicionar Plano"}
            </Button>
            <Button onClick={onClose}>Cancelar</Button>
          </ModalFooter>
        </form>
      </ModalContent>
    </Modal>
  );
};

export default CreateNewPlanModal;
