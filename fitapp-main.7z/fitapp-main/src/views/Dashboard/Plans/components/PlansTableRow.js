import {
  Avatar,
  Badge,
  Flex,
  Td,
  Text,
  Tr,
  useColorModeValue,
} from "@chakra-ui/react";
import React from "react";
import { formatCurrency } from "utils/formatCurrency";

function PlansTableRow(props) {
  const { name, description, value, services, exercises, actions } = props;
  const textColor = useColorModeValue("gray.700", "white");

  return (
    <Tr>
      <Td minWidth={{ sm: "250px" }} pl="0px">
        <Flex align="center" py=".8rem" minWidth="100%" flexWrap="nowrap">
          <Flex direction="column">
            <Text
              fontSize="md"
              color={textColor}
              fontWeight="bold"
              minWidth="100%"
            >
              {name}
            </Text>
            <Text fontSize="sm" color="gray.400" fontWeight="normal">
              {description}
            </Text>
          </Flex>
        </Flex>
      </Td>
      <Td>
        <Text fontSize="md" color={textColor} fontWeight="bold">
          {services !== undefined
            ? formatCurrency(value)
            : "Não foi possível carregar valor"}
        </Text>
      </Td>
      <Td width="250px">
        <Flex flexWrap="wrap" gap="8px">
          {services.length > 0 ? (
            services.map((service) => {
              return (
                <Badge colorScheme="purple" variant="solid">
                  {service.service.name}
                </Badge>
              );
            })
          ) : (
            <Badge variant="solid">0 serviços inclusos</Badge>
          )}
        </Flex>
      </Td>
      <Td width="250px">
        <Flex flexWrap="wrap" gap="8px">
          {exercises.length > 0 ? (
            exercises.map((exercise) => {
              return (
                <Badge colorScheme="green" variant="solid">
                  {exercise.exercise.name}
                </Badge>
              );
            })
          ) : (
            <Badge variant="solid">0 exercícios inclusos</Badge>
          )}
        </Flex>
      </Td>
      <Td>
        <Flex alignItems="center" justifyItems="center">
          {actions}
        </Flex>
      </Td>
    </Tr>
  );
}

export default PlansTableRow;
