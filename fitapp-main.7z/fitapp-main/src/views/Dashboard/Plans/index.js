// Chakra imports
import { CircularProgress, Flex } from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import ListingPlans from "./components/ListingPlans";
import { useGetPlans } from "hooks/usePlans";

function Plans() {
  const { data, isLoading, refetch } = useGetPlans(); // Hook para buscar dados
  const [plans, setPlans] = useState([]);

  useEffect(() => {
    if (data && data.data) {
      setPlans(data.data);
    }
  }, [data]);

  const reloadPlans = async () => {
    const newData = await refetch();
    setPlans(newData.data);
  };

  if (isLoading) {
    return (
      <Flex
        id="loading"
        sx={{ height: "80vh", width: "100%" }}
        justifyContent="center"
        alignItems="center"
      >
        <CircularProgress isIndeterminate color="red.500" size={100} />
      </Flex>
    );
  }

  return (
    <Flex direction="column" pt={{ base: "120px", md: "75px" }}>
      <ListingPlans
        title={"Planos disponíveis"}
        captions={["Nome", "Preço", "Serviços", "Exercícios", " Ações"]}
        data={plans}
        reloadPlans={reloadPlans}
      />
    </Flex>
  );
}

export default Plans;
