import { IconButton, Tooltip } from "@chakra-ui/react";
import { Edit, Trash } from "lucide-react";

const ActionsService = ({ onEdit, onDelete }) => {
  return (
    <>
      <Tooltip label="Editar Serviço">
        <IconButton
          icon={<Edit size={16} />}
          onClick={onEdit}
          aria-label="Editar"
          mr={2}
        />
      </Tooltip>
      <Tooltip label="Deletar Serviço">
        <IconButton
          icon={<Trash size={16} />}
          onClick={onDelete}
          aria-label="Deletar"
        />
      </Tooltip>
    </>
  );
};

export default ActionsService;
