import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  FormControl,
  FormLabel,
  Input,
  Button,
  FormErrorMessage,
  useToast,
  Textarea,
} from "@chakra-ui/react";
import { useCreateService, useUpdateService } from "hooks/useServices";
import { useEffect } from "react";
import { useForm } from "react-hook-form";

const CreateNewServiceModal = ({
  isOpen,
  setIsOpen,
  reloadServices,
  serviceData = null,
  isEditMode = false,
}) => {
  const {
    handleSubmit,
    register,
    reset,
    clearErrors,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm();
  const toast = useToast();

  useEffect(() => {
    if (isEditMode && serviceData) {
      setValue("name", serviceData.name);
      setValue("description", serviceData.description);
    } else if (!isEditMode) {
      reset({ name: "", description: "", value: "" });
    }
  }, [isEditMode, serviceData, setValue, reset]);

  const onSubmit = async (values) => {
    if (isEditMode) {
      updateService.mutate({ id: serviceData.id, data: values });
    } else {
      createService.mutate({ data: values });
    }
  };

  const createService = useCreateService({
    onSuccess: () => {
      toast({
        title: "Serviço criado com sucesso!",
        status: "success",
        duration: 3000,
        isClosable: true,
        position: "bottom-right",
      });
      reloadServices();
      setIsOpen(false);
      reset();
    },
    onError: (error) => {
      toast({
        title: "Erro ao criar exercício.",
        description: error.message || "Tente novamente mais tarde.",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom-right",
      });
    },
  });

  const updateService = useUpdateService({
    onSuccess: () => {
      toast({
        title: "Serviço atualizado com sucesso!",
        status: "success",
        duration: 3000,
        isClosable: true,
        position: "bottom-right",
      });
      reloadServices();
      setIsOpen(false);
      reset();
    },
    onError: (error) => {
      toast({
        title: "Erro ao atualizar exercício.",
        description: error.message || "Tente novamente mais tarde.",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom-right",
      });
    },
  });

  const onClose = () => {
    clearErrors();
    setIsOpen(false);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>
          {isEditMode ? "Editar Serviço" : "Adicionar novo Serviço"}
        </ModalHeader>
        <ModalCloseButton onClick={onClose} />
        <form onSubmit={handleSubmit(onSubmit)}>
          <ModalBody pb={6}>
            <FormControl isInvalid={errors.name}>
              <FormLabel htmlFor="name">Nome</FormLabel>
              <Input
                id="name"
                placeholder="Nome do exercício"
                {...register("name", {
                  required: "Este campo é obrigatório",
                  minLength: {
                    value: 4,
                    message: "O nome precisa ter mais que 4 caracteres",
                  },
                })}
              />
              <FormErrorMessage>
                {errors.name && errors.name.message}
              </FormErrorMessage>
            </FormControl>
            <FormControl mt={4} isInvalid={errors.description}>
              <FormLabel htmlFor="description">Descrição</FormLabel>
              <Textarea
                id="description"
                placeholder="Descreva o exercício"
                {...register("description")}
              />
              <FormErrorMessage>
                {errors.description && errors.description.message}
              </FormErrorMessage>
            </FormControl>
          </ModalBody>
          <ModalFooter>
            <Button
              type="submit"
              isLoading={isSubmitting}
              loadingText={isEditMode ? "Salvando" : "Adicionando"}
              mr={3}
              variant="solid"
              bgColor="red.500"
              _hover={{ bgColor: "red.600" }}
            >
              {isEditMode ? "Salvar Alterações" : "Adicionar Serviço"}
            </Button>
            <Button onClick={onClose}>Cancelar</Button>
          </ModalFooter>
        </form>
      </ModalContent>
    </Modal>
  );
};

export default CreateNewServiceModal;
