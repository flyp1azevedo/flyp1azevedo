// Chakra imports
import { CircularProgress, Flex } from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import ListingServices from "./components/ListingServices";
import { useGetServices } from "hooks/useServices";

function Services() {
  const { data, isLoading, refetch } = useGetServices(); // Hook para buscar dados
  const [services, setServices] = useState([]);

  useEffect(() => {
    if (data && data.data) {
      setServices(data.data);
    }
  }, [data]);

  const reloadServices = async () => {
    const newData = await refetch();
    setServices(newData.data);
  };

  if (isLoading) {
    return (
      <Flex
        id="loading"
        sx={{ height: "80vh", width: "100%" }}
        justifyContent="center"
        alignItems="center"
      >
        <CircularProgress isIndeterminate color="red.500" size={100} />
      </Flex>
    );
  }

  return (
    <Flex direction="column" pt={{ base: "120px", md: "75px" }}>
      <ListingServices
        title={"Serviços disponíveis"}
        captions={["Nome", "Descrição", " Ações"]}
        data={services}
        reloadServices={reloadServices}
      />
    </Flex>
  );
}

export default Services;
