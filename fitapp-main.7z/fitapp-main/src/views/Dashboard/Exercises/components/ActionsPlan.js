import { IconButton, Tooltip } from "@chakra-ui/react";
import { Edit, Trash } from "lucide-react";

const ActionsPlan = ({ onEdit, onDelete }) => {
  return (
    <>
      <Tooltip label="Editar Exercício">
        <IconButton
          icon={<Edit size={16} />}
          onClick={onEdit}
          aria-label="Editar"
          mr={2}
        />
      </Tooltip>
      <Tooltip label="Deletar Exercício">
        <IconButton
          icon={<Trash size={16} />}
          onClick={onDelete}
          aria-label="Deletar"
        />
      </Tooltip>
    </>
  );
};

export default ActionsPlan;
