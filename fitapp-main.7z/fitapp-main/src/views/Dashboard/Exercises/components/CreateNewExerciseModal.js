import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  FormControl,
  FormLabel,
  Input,
  Button,
  FormErrorMessage,
  useToast,
  Textarea,
} from "@chakra-ui/react";
import { useCreateExercise, useUpdateExercise } from "hooks/useExercises";
import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { createExercise } from "services/api";

const CreateNewExerciseModal = ({
  isOpen,
  setIsOpen,
  reloadExercises,
  exerciseData = null,
  isEditMode = false,
}) => {
  const {
    handleSubmit,
    register,
    reset,
    clearErrors,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm();

  const toast = useToast();

  useEffect(() => {
    if (isEditMode && exerciseData) {
      setValue("name", exerciseData.name);
      setValue("description", exerciseData.description);
    } else if (!isEditMode) {
      reset({ name: "", description: "", value: "" });
    }
  }, [isEditMode, exerciseData, setValue, reset]);

  const onSubmit = async (values) => {
    if (isEditMode) {
      updateExercise.mutate({ id: exerciseData.id, data: values });
    } else {
      createExercise.mutate({ data: values });
    }
  };

  const createExercise = useCreateExercise({
    onSuccess: () => {
      toast({
        title: "Exercício criado com sucesso!",
        status: "success",
        duration: 3000,
        isClosable: true,
        position: "bottom-right",
      });
      reloadExercises();
      setIsOpen(false);
      reset();
    },
    onError: (error) => {
      toast({
        title: "Erro ao criar exercício.",
        description: error.message || "Tente novamente mais tarde.",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom-right",
      });
    },
  });

  const updateExercise = useUpdateExercise({
    onSuccess: () => {
      toast({
        title: "Exercício atualizado com sucesso!",
        status: "success",
        duration: 3000,
        isClosable: true,
        position: "bottom-right",
      });
      reloadExercises();
      setIsOpen(false);
      reset();
    },
    onError: (error) => {
      toast({
        title: "Erro ao atualizar exercício.",
        description: error.message || "Tente novamente mais tarde.",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom-right",
      });
    },
  });

  const onClose = () => {
    clearErrors();
    setIsOpen(false);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>
          {isEditMode ? "Editar Exercício" : "Adicionar novo Exercício"}
        </ModalHeader>
        <ModalCloseButton onClick={onClose} />
        <form onSubmit={handleSubmit(onSubmit)}>
          <ModalBody pb={6}>
            <FormControl isInvalid={errors.name}>
              <FormLabel htmlFor="name">Nome</FormLabel>
              <Input
                id="name"
                placeholder="Nome do exercício"
                {...register("name", {
                  required: "Este campo é obrigatório",
                  minLength: {
                    value: 4,
                    message: "O nome precisa ter mais que 4 caracteres",
                  },
                })}
              />
              <FormErrorMessage>
                {errors.name && errors.name.message}
              </FormErrorMessage>
            </FormControl>
            <FormControl mt={4} isInvalid={errors.description}>
              <FormLabel htmlFor="description">Descrição</FormLabel>
              <Textarea
                helperText=""
                id="description"
                placeholder="Descreva o exercício"
                {...register("description")}
              />
              <FormErrorMessage>
                {errors.description && errors.description.message}
              </FormErrorMessage>
            </FormControl>
          </ModalBody>
          <ModalFooter>
            <Button
              type="submit"
              isLoading={isSubmitting}
              loadingText={isEditMode ? "Salvando" : "Adicionando"}
              mr={3}
              variant="solid"
              bgColor="red.500"
              _hover={{ bgColor: "red.600" }}
            >
              {isEditMode ? "Salvar Alterações" : "Adicionar Exercício"}
            </Button>
            <Button onClick={onClose}>Cancelar</Button>
          </ModalFooter>
        </form>
      </ModalContent>
    </Modal>
  );
};

export default CreateNewExerciseModal;
