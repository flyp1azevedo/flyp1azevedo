// Chakra imports
import {
  Button,
  Table,
  Tbody,
  Td,
  Text,
  Th,
  Thead,
  Tr,
  useColorModeValue,
  useToast,
} from "@chakra-ui/react";
// Custom components
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardHeader from "components/Card/CardHeader.js";
import ExercisesTableRow from "./ExercisesTableRow";
import CreateNewExerciseModal from "./CreateNewExerciseModal";
import React, { useState } from "react";
import { Plus } from "lucide-react";
import ActionsPlan from "./ActionsPlan";
import { useDeleteExercise } from "hooks/useExercises";

const ListingExercises = ({ title, captions, data, reloadExercises }) => {
  const textColor = useColorModeValue("gray.700", "white");
  const [isOpen, setIsOpen] = useState(false);
  const [selectedExercise, setSelectedExercise] = useState(null);
  const toast = useToast();

  const openEditModal = (plan) => {
    setSelectedExercise(plan);
    setIsOpen(true);
  };

  const deleteExercise = useDeleteExercise({
    onSuccess: () => {
      reloadExercises();
      toast({
        title: "Exercício deletado com sucesso!",
        status: "success",
        duration: 3000,
        isClosable: true,
        position: "bottom-right",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao deletar exercício.",
        description: "Erro: " + error,
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom-right",
      });
    },
  });

  const handleDelete = async (id) => {
    if (window.confirm("Tem certeza que deseja deletar este exercício?")) {
      deleteExercise.mutate(id);
    }
  };

  return (
    <>
      <Card overflowX={{ sm: "scroll", xl: "hidden" }}>
        <CardHeader
          p="6px 0px 22px 0px"
          flex
          alignItems="center"
          justifyContent="space-between"
        >
          <Text fontSize="xl" color={textColor} fontWeight="bold">
            {title}
          </Text>
          <Button
            leftIcon={<Plus size={16} />}
            bgColor="red.500"
            _hover={{ bgColor: "red.600" }}
            onClick={() => {
              setSelectedExercise(null);
              setIsOpen(true);
            }}
          >
            Criar novo Exercício
          </Button>
        </CardHeader>
        <CardBody>
          <Table variant="simple" color={textColor}>
            <Thead>
              <Tr my=".8rem" pl="0px" color="gray.400">
                {captions.map((caption, idx) => {
                  return (
                    <Th
                      color="gray.400"
                      key={idx}
                      ps={idx === 0 ? "0px" : null}
                    >
                      {caption}
                    </Th>
                  );
                })}
              </Tr>
            </Thead>
            <Tbody>
              {Array.isArray(data) && data.length > 0 ? (
                data.map((row) => (
                  <ExercisesTableRow
                    key={row.id}
                    name={row.name}
                    description={row.description}
                    actions={
                      <ActionsPlan
                        onEdit={() => openEditModal(row)}
                        onDelete={() => handleDelete(row.id)}
                      />
                    }
                  />
                ))
              ) : (
                <Tr>
                  <Td colSpan={captions.length} textAlign="center">
                    Nenhum exercício disponível
                  </Td>
                </Tr>
              )}
            </Tbody>
          </Table>
        </CardBody>
      </Card>
      <CreateNewExerciseModal
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        reloadExercises={reloadExercises}
        exerciseData={selectedExercise}
        isEditMode={!!selectedExercise}
      />
    </>
  );
};

export default ListingExercises;
