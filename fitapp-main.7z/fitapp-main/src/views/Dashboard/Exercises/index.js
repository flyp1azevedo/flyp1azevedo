// Chakra imports
import { CircularProgress, Flex } from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import ListingExercises from "./components/ListingExercises";
import { useGetExercises } from "hooks/useExercises";

function Exercises() {
  const { data, isLoading, refetch } = useGetExercises(); // Hook para buscar dados
  const [exercises, setExercises] = useState([]);

  useEffect(() => {
    if (data && data.data) {
      setExercises(data.data);
    }
  }, [data]);

  const reloadExercises = async () => {
    const newData = await refetch();
    setExercises(newData.data);
  };

  if (isLoading) {
    return (
      <Flex
        id="loading"
        sx={{ height: "80vh", width: "100%" }}
        justifyContent="center"
        alignItems="center"
      >
        <CircularProgress isIndeterminate color="red.500" size={100} />
      </Flex>
    );
  }

  return (
    <Flex direction="column" pt={{ base: "120px", md: "75px" }}>
      <ListingExercises
        title={"Exercícios disponíveis"}
        captions={["Nome", "Descrição", " Ações"]}
        data={exercises}
        reloadExercises={reloadExercises}
      />
    </Flex>
  );
}

export default Exercises;
