import { CircularProgress, Flex } from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import ListingInvoices from "./components/ListingInvoices";
import { useGetInvoices } from "hooks/useInvoices";

function Invoices() {
  const { data, isLoading, refetch } = useGetInvoices();
  const [invoices, setInvoices] = useState([]);

  useEffect(() => {
    if (data && data.data) {
      setInvoices(data.data);
    }
  }, [data]);

  const reloadInvoices = async () => {
    const newData = await refetch();
    setInvoices(newData.data);
  };

  if (isLoading) {
    return (
      <Flex
        id="loading"
        sx={{ height: "80vh", width: "100%" }}
        justifyContent="center"
        alignItems="center"
      >
        <CircularProgress isIndeterminate color="red.500" size={100} />
      </Flex>
    );
  }

  return (
    <Flex direction="column" pt={{ base: "120px", md: "75px" }}>
      <ListingInvoices
        title={"Faturas disponíveis"}
        captions={["Cadastro", "Plano", "Valor", "Venvimento", "Status", " Ações"]}
        data={invoices}
        reloadInvoices={reloadInvoices}
      />
    </Flex>
  );
}

export default Invoices;
