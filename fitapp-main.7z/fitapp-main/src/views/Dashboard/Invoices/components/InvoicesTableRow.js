import {
  Avatar,
  Flex,
  Td,
  Text,
  Tr,
  useColorModeValue,
} from "@chakra-ui/react";
import React from "react";

function InvoicesTableRow(props) {
  const { name, description, actions } = props;
  const textColor = useColorModeValue("gray.700", "white");

  return (
    <Tr>
      <Td minWidth={{ sm: "250px" }} pl="0px">
        <Flex align="center" py=".8rem" minWidth="100%" flexWrap="nowrap">
          <Text
            fontSize="md"
            color={textColor}
            fontWeight="bold"
            minWidth="100%"
          >
            {name}
          </Text>
        </Flex>
      </Td>
      <Td>
        <Text fontSize="md" color="gray.400">
          {description}
        </Text>
      </Td>
      <Td>
        <Flex alignItems="center" justifyItems="center">
          {actions}
        </Flex>
      </Td>
    </Tr>
  );
}

export default InvoicesTableRow;
