import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  FormControl,
  FormLabel,
  Input,
  Button,
  FormErrorMessage,
  useToast,
  Select,
  Radio,
  RadioGroup,
  Stack
} from "@chakra-ui/react";
import { useCreateInvoice, useUpdateInvoice } from "hooks/useInvoices";
import { useEffect } from "react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { getPeoples, getPlans } from "services/api";

const CreateNewInvoiceModal = ({
  isOpen,
  setIsOpen,
  reloadInvoices,
  invoiceData = null,
  isEditMode = false,
}) => {
  const {
    handleSubmit,
    register,
    reset,
    clearErrors,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm();

  const [loadingData, setLoadingData] = useState();
  const [selectedPeople, setSelectedPeople] = useState([]);
  const [selectedPlan, setSelectedPlan] = useState([]);
  const [peoplesOptions, setPeoplesOptions] = useState([]);
  const [plansOptions, setPlansOptions] = useState([]);
  const [statusOption, setStatusOption] = useState(['PENDENTE']);

  const toast = useToast();

  const getPeoplesData = async () => {
    const data = await getPeoples();
    if (data) {
      setPeoplesOptions(
        data.data.map((peoples) => ({
          value: peoples.id,
          label: peoples.firstName,
        }))
      );
    }
  };

  const getPlansData = async () => {
    const data = await getPlans();
    if (data) {
      setPlansOptions(
        data.data.map((plans) => ({
          value: plans.id,
          label: plans.name,
        }))
      );
    }
  };

  useEffect(() => {
    if (isOpen) {
      setLoadingData(true);

      getPeoplesData();
      getPlansData();

      if (isEditMode && invoiceData) {
        setSelectedPeople(
          invoiceData.people.map((item) => ({
            value: item.peopleId,
            label: item.people.name,
          }))
        );

        setSelectedPlan(
          invoiceData.plan.map((item) => ({
            value: item.planId,
            label: item.plan.name,
          }))
        );

        setValue("dueDate", invoiceData.dueDate);
        setValue("status", invoiceData.status);
      } else if (!isEditMode) {
        setSelectedPeople([]);
        setSelectedPlan([]);
        reset({ dueDate: "", status: "PENDENTE" });
      }
    }
  }, [isOpen, isEditMode, invoiceData, setValue, reset]);

  const onSubmit = async (values) => {

    if (isEditMode) {
      updateInvoice.mutate({ id: invoiceData.id, data: values });
    } else {
      createInvoice.mutate({ data: values });
    }
  };

  const createInvoice = useCreateInvoice({
    onSuccess: () => {
      toast({
        title: "Fatura criada com sucesso!",
        status: "success",
        duration: 3000,
        isClosable: true,
        position: "bottom-right",
      });
      reloadInvoices();
      setIsOpen(false);
      reset();
    },
    onError: (error) => {
      toast({
        title: "Erro ao criar fatura.",
        description: error.message || "Tente novamente mais tarde.",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom-right",
      });
    },
  });

  const updateInvoice = useUpdateInvoice({
    onSuccess: () => {
      toast({
        title: "Fatura atualizada com sucesso!",
        status: "success",
        duration: 3000,
        isClosable: true,
        position: "bottom-right",
      });
      reloadInvoices();
      setIsOpen(false);
      reset();
    },
    onError: (error) => {
      toast({
        title: "Erro ao atualizar fatura.",
        description: error.message || "Tente novamente mais tarde.",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom-right",
      });
    },
  });

  const onClose = () => {
    clearErrors();
    setIsOpen(false);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>
          {isEditMode ? "Editar Fatura" : "Adicionar novo Fatura"}
        </ModalHeader>
        <ModalCloseButton onClick={onClose} />
        <form onSubmit={handleSubmit(onSubmit)}>
          <ModalBody pb={6}>
            <FormControl mt={4} isDisabled={loadingData}>
              <FormLabel>Cadastro</FormLabel>
              <Select
                isSearchable
                isLoading={loadingData}
                loadingText="Carregando..."
                options={peoplesOptions}
                value={selectedPeople}
                onChange={(selected) => setSelectedPeople(selected)}
                placeholder="Selecione o cadastro"
              />
            </FormControl>
            <FormControl mt={4} isDisabled={loadingData}>
              <FormLabel>Plano</FormLabel>
              <Select
                isSearchable
                isLoading={loadingData}
                loadingText="Carregando..."
                options={plansOptions}
                value={selectedPlan}
                onChange={(selected) => setSelectedPlan(selected)}
                placeholder="Selecione o Plano"
              />
            </FormControl>
            <FormControl isInvalid={errors.dueDate}>
              <FormLabel htmlFor="dueDate">Vencimento</FormLabel>
              <Input
                id="dueDate"
                type="date"
                placeholder="vencimento da fatur"
                {...register("dueDate", {
                  required: "Este campo é obrigatório",
                })}
              />
              <FormErrorMessage>
                {errors.dueDate && errors.dueDate.message}
              </FormErrorMessage>
            </FormControl>
            <FormControl mt={4} isInvalid={errors.status}>
              <FormLabel htmlFor="status">Status</FormLabel>
              <RadioGroup value={statusOption} id="status" onChange={setStatusOption}>
                <Stack spacing={5} direction='row'>
                  <Radio colorScheme='red' value='PENDENTE'>
                    Pendente
                  </Radio>
                  <Radio colorScheme='green' value='PAGA'>
                    Paga
                  </Radio>
                </Stack>
              </RadioGroup>
              <FormErrorMessage>
                {errors.status && errors.status.message}
              </FormErrorMessage>
            </FormControl>
          </ModalBody>
          <ModalFooter>
            <Button
              type="submit"
              isLoading={isSubmitting}
              loadingText={isEditMode ? "Salvando" : "Adicionando"}
              mr={3}
              variant="solid"
              bgColor="red.500"
              _hover={{ bgColor: "red.600" }}
            >
              {isEditMode ? "Salvar Alterações" : "Adicionar Fatura"}
            </Button>
            <Button onClick={onClose}>Cancelar</Button>
          </ModalFooter>
        </form>
      </ModalContent>
    </Modal>
  );
};

export default CreateNewInvoiceModal;
