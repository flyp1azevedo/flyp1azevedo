import { IconButton, Tooltip } from "@chakra-ui/react";
import { Edit, Trash } from "lucide-react";

const InvoiceActions = ({ onEdit, onDelete }) => {
  return (
    <>
      <Tooltip label="Editar Fatura">
        <IconButton
          icon={<Edit size={16} />}
          onClick={onEdit}
          aria-label="Editar"
          mr={2}
        />
      </Tooltip>
      <Tooltip label="Deletar Fatura">
        <IconButton
          icon={<Trash size={16} />}
          onClick={onDelete}
          aria-label="Deletar"
        />
      </Tooltip>
    </>
  );
};

export default InvoiceActions;
