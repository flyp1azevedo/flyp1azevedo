// Chakra imports
import {
  Button,
  Table,
  Tbody,
  Td,
  Text,
  Th,
  Thead,
  Tr,
  useColorModeValue,
  useToast,
} from "@chakra-ui/react";
// Custom components
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardHeader from "components/Card/CardHeader.js";
import InvoicesTableRow from "./InvoicesTableRow";
import CreateNewInvoiceModal from "./CreateNewInvoiceModal";
import React, { useState } from "react";
import { Plus } from "lucide-react";
import ActionsPlan from "./InvoiceActions";
import { useDeleteInvoice } from "hooks/useInvoices";

const ListingInvoices = ({ title, captions, data, reloadInvoices }) => {
  const textColor = useColorModeValue("gray.700", "white");
  const [isOpen, setIsOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const toast = useToast();

  const openEditModal = (plan) => {
    setSelectedInvoice(plan);
    setIsOpen(true);
  };

  const deleteInvoice = useDeleteInvoice({
    onSuccess: () => {
      reloadInvoices();
      toast({
        title: "Fatura deletada com sucesso!",
        status: "success",
        duration: 3000,
        isClosable: true,
        position: "bottom-right",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao deletar fatura.",
        description: "Erro: " + error,
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom-right",
      });
    },
  });

  const handleDelete = async (id) => {
    if (window.confirm("Tem certeza que deseja deletar esta fatura?")) {
      deleteInvoice.mutate(id);
    }
  };

  return (
    <>
      <Card overflowX={{ sm: "scroll", xl: "hidden" }}>
        <CardHeader
          p="6px 0px 22px 0px"
          flex
          alignItems="center"
          justifyContent="space-between"
        >
          <Text fontSize="xl" color={textColor} fontWeight="bold">
            {title}
          </Text>
          <Button
            leftIcon={<Plus size={16} />}
            bgColor="red.500"
            _hover={{ bgColor: "red.600" }}
            onClick={() => {
              setSelectedInvoice(null);
              setIsOpen(true);
            }}
          >
            Criar nova Fatura
          </Button>
        </CardHeader>
        <CardBody>
          <Table variant="simple" color={textColor}>
            <Thead>
              <Tr my=".8rem" pl="0px" color="gray.400">
                {captions.map((caption, idx) => {
                  return (
                    <Th
                      color="gray.400"
                      key={idx}
                      ps={idx === 0 ? "0px" : null}
                    >
                      {caption}
                    </Th>
                  );
                })}
              </Tr>
            </Thead>
            <Tbody>
              {Array.isArray(data) && data.length > 0 ? (
                data.map((row) => (
                  <InvoicesTableRow
                    key={row.id}
                    people={row.people.firstName}
                    plan={row.plan.name}
                    value={row.plan.value}
                    dueDate={row.dueDate}
                    status={row.status}
                    actions={
                      <ActionsPlan
                        onEdit={() => openEditModal(row)}
                        onDelete={() => handleDelete(row.id)}
                      />
                    }
                  />
                ))
              ) : (
                <Tr>
                  <Td colSpan={captions.length} textAlign="center">
                    Nenhuma fatura disponível
                  </Td>
                </Tr>
              )}
            </Tbody>
          </Table>
        </CardBody>
      </Card>
      <CreateNewInvoiceModal
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        reloadInvoices={reloadInvoices}
        invoiceData={selectedInvoice}
        isEditMode={!!selectedInvoice}
      />
    </>
  );
};

export default ListingInvoices;
