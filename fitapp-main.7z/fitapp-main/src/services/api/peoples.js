import { api } from './index'

export const getPeoples = async () => {
  return await api.get('/peoples')
}

export const createPeople = async (data) => {
  return await api.post("/peoples", {
    peopleId: data.peopleId,
    planId: data.planId,
    dueDate: data.dueDate,
    status: data.status
  });
};

export const updatePeople = async (id, data) => {
  return await api.put(`/peoples/${id}`, {
    peopleId: data.peopleId,
    planId: data.planId,
    dueDate: data.dueDate,
    status: data.status
  });
};

export const deletePeople = async (id) => {
  return await api.delete(`/peoples/${id}`, {});
}