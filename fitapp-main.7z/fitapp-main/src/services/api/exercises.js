import { api } from "./index";

export const getExercises = async () => {
  return await api.get("/exercise");
};

export const createExercise = async (data) => {
  return await api.post("/exercise", {
    name: data.name,
    description: data.description,
  });
};

export const updateExercise = async (id, data) => {
  return await api.put(`/exercise/${id}`, {
    name: data.name,
    description: data.description,
  });
};

export const deleteExercise = async (id) => {
  return await api.delete(`/exercise/${id}`, {});
};
