import { api } from "./index";

export const getServices = async () => {
  return await api.get("/services");
};

export const createService = async (data) => {
  return await api.post("/services", {
    name: data.name,
    description: data.description,
  });
};

export const updateService = async (id, data) => {
  return await api.put(`/services/${id}`, {
    name: data.name,
    description: data.description,
  });
};

export const deleteService = async (id) => {
  return await api.delete(`/services/${id}`, {});
};
