import axios from "axios";
import { getPeoples, createPeople, updatePeople, deletePeople } from "./peoples";
import { getPlans, createPlan, updatePlan, deletePlan } from "./plans";
import {
  getServices,
  createService,
  updateService,
  deleteService,
} from "./services";
import {
  getExercises,
  createExercise,
  updateExercise,
  deleteExercise,
} from "./exercises";
import {
  getInvoices,
  createInvoice,
  updateInvoice,
  deleteInvoice,
} from "./invoices";

export const api = axios.create({
  baseURL: "http://localhost:3000",
});

export {
  getPeoples,
  createPeople,
  updatePeople,
  deletePeople,
  getPlans,
  createPlan,
  updatePlan,
  deletePlan,
  getServices,
  createService,
  updateService,
  deleteService,
  getExercises,
  createExercise,
  updateExercise,
  deleteExercise,
  getInvoices,
  createInvoice,
  updateInvoice,
  deleteInvoice
};
