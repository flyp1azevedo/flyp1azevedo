import { api } from "./index";

export const getPlans = async () => {
  return await api.get("/plan");
};

export const createPlan = async (data) => {
  return await api.post("/plan", {
    name: data.name,
    description: data.description,
    value: data.value,
    serviceIds: data.serviceIds,
    exerciseIds: data.exerciseIds,
  });
};

export const updatePlan = async (id, data) => {
  return await api.put(`/plan/${id}`, {
    name: data.name,
    description: data.description,
    value: data.value,
    serviceIds: data.serviceIds,
    exerciseIds: data.exerciseIds,
  });
};

export const deletePlan = async (id) => {
  return await api.delete(`/plan/${id}`, {});
};
