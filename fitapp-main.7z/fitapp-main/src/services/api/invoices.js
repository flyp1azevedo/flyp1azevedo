import { api } from "./index";

export const getInvoices = async () => {
  return await api.get("/invoices");
};

export const createInvoice = async (data) => {
  return await api.post("/invoices", {
    peopleId: data.peopleId,
    planId: data.planId,
    dueDate: data.dueDate,
    status: data.status
  });
};

export const updateInvoice = async (id, data) => {
  return await api.put(`/invoices/${id}`, {
    peopleId: data.peopleId,
    planId: data.planId,
    dueDate: data.dueDate,
    status: data.status
  });
};

export const deleteInvoice = async (id) => {
  return await api.delete(`/invoices/${id}`, {});
};
