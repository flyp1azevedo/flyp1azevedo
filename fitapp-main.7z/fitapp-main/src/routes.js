// import
import Dashboard from "views/Dashboard/Dashboard";
import Peoples from "views/Dashboard/Peoples";
import Invoices from "views/Dashboard/Invoices";
import Plans from "views/Dashboard/Plans";
import Exercises from "views/Dashboard/Exercises";
import Services from "views/Dashboard/Services";
import SignIn from "views/Auth/SignIn.js";

import { PersonIcon, DocumentIcon, RocketIcon } from "components/Icons/Icons";
import {
  CreditCard,
  Dumbbell,
  Home,
  Notebook,
  Package,
  Package2,
  User,
} from "lucide-react";
import { Icon } from "@chakra-ui/react";

var dashRoutes = [
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: <Icon as={Home} color="inherit" />,
    component: Dashboard,
    layout: "/admin",
  },
  {
    path: "/peoples",
    name: "Cadastors",
    icon: <Icon as={User} color="inherit" />,
    component: Peoples,
    layout: "/admin",
  },
  {
    path: "/plans",
    name: "Planos",
    icon: <Icon as={Notebook} color="inherit" />,
    component: Plans,
    layout: "/admin",
  },
  {
    path: "/exercises",
    name: "Exercícios",
    icon: <Icon as={Dumbbell} color="inherit" />,
    component: Exercises,
    layout: "/admin",
  },
  {
    path: "/services",
    name: "Serviços",
    icon: <Icon as={Package2} color="inherit" />,
    component: Services,
    layout: "/admin",
  },
  {
    path: "/invoices",
    name: "Faturas",
    icon: <Icon as={CreditCard} color="inherit" />,
    component: Invoices,
    layout: "/admin",
  },
  {
    path: "/signin",
    name: "Sign In",
    icon: <DocumentIcon color="inherit" />,
    component: SignIn,
    layout: "/auth",
  }
];

export default dashRoutes;
