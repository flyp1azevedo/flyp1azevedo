import { KEYS } from '../constants'

export const useRememberMe = () => {

  const setRememberMe = (rememberMe = false) => {
    localStorage.setItem(KEYS.REMEMBER_ME, rememberMe)
  }

  return { setRememberMe }
}