import { useAccessToken } from "./useAccessToken";

export default {
  useAccessToken,
};
