import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { KEYS } from "../constants";
import { getPlans, createPlan, updatePlan, deletePlan } from "services/api";

export const useGetPlans = (options = {}) => {
  const result = useQuery({
    queryKey: [KEYS.PLANS],
    queryFn: getPlans,
    ...options,
  });

  return result;
};

export const useCreatePlan = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: ({ data }) => createPlan(data),
    onSuccess: () => {
      query.invalidateQueries([KEYS.PLANS]);
    },
    ...options,
  });

  return result;
};

export const useUpdatePlan = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: ({ id, data }) => updatePlan(id, data),
    onSuccess: () => {
      query.invalidateQueries([KEYS.PLANS]);
    },
    ...options,
  });

  return result;
};

export const useDeletePlan = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: (id) => deletePlan(id),
    onSuccess: () => {
      query.invalidateQueries([KEYS.PLANS]);
    },
    ...options,
  });

  return result;
};
