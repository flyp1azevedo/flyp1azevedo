import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { KEYS } from "../constants";
import {
  getServices,
  createService,
  updateService,
  deleteService,
} from "services/api";

export const useGetServices = (options = {}) => {
  const result = useQuery({
    queryKey: [KEYS.SERVICES],
    queryFn: getServices,
    ...options,
  });

  return result;
};

export const useCreateService = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: ({ data }) => createService(data),
    onSuccess: () => {
      query.invalidateQueries([KEYS.SERVICES]);
    },
    ...options,
  });

  return result;
};

export const useUpdateService = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: ({ id, data }) => updateService(id, data),
    onSuccess: () => {
      query.invalidateQueries([KEYS.SERVICES]);
    },
    ...options,
  });

  return result;
};

export const useDeleteService = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: (id) => deleteService(id),
    onSuccess: () => {
      query.invalidateQueries([KEYS.SERVICES]);
    },
    ...options,
  });

  return result;
};
