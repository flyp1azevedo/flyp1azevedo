import { KEYS } from "../constants";

export const useAccessToken = () => {
  const setAccessToken = (token) => {
    localStorage.setItem(KEYS.ACCESS_TOKEN, token);
  };

  const clearAccessToken = () => {
    localStorage.removeItem(KEYS.ACCESS_TOKEN);
  };

  const getAccessToken = () => {
    return localStorage.getItem(KEYS.ACCESS_TOKEN);
  };

  return { setAccessToken, clearAccessToken, getAccessToken };
};
