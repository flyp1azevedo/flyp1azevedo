import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { KEYS } from "../constants";
import {
  getInvoices,
  createInvoice,
  updateInvoice,
  deleteInvoice,
} from "services/api";

export const useGetInvoices = (options = {}) => {
  const result = useQuery({
    queryKey: [KEYS.INVOICES],
    queryFn: getInvoices,
    ...options,
  });

  return result;
};

export const useCreateInvoice = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: ({ data }) => createInvoice(data),
    onSuccess: () => {
      query.invalidateQueries([KEYS.INVOICES]);
    },
    ...options,
  });

  return result;
};

export const useUpdateInvoice = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: ({ id, data }) => updateInvoice(id, data),
    onSuccess: () => {
      query.invalidateQueries([KEYS.INVOICES]);
    },
    ...options,
  });

  return result;
};

export const useDeleteInvoice = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: (id) => deleteInvoice(id),
    onSuccess: () => {
      query.invalidateQueries([KEYS.INVOICES]);
    },
    ...options,
  });

  return result;
};
