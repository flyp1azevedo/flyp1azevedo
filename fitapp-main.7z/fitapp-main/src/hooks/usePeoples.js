import { useQuery } from "@tanstack/react-query";
import { KEYS } from "../constants";
import { getPeoples, createPeople, updatePeople, deletePeople } from "services/api";

export const useGetPeoples = (options = {}) => {
  const result = useQuery({
    queryKey: [KEYS.PEOPLES],
    queryFn: getPeoples,
    ...options,
  });

  return result;
};

export const useCreatePeople = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: ({ data }) => createPeople(data),
    onSuccess: () => {
      query.invalidateQueries([KEYS.PEOPLES]);
    },
    ...options,
  });

  return result;
};

export const useUpdatePeople = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: ({ id, data }) => updatePeople(id, data),
    onSuccess: () => {
      query.invalidateQueries([KEYS.PEOPLES]);
    },
    ...options,
  });

  return result;
};

export const useDeletePeople = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: (id) => deletePeople(id),
    onSuccess: () => {
      query.invalidateQueries([KEYS.PEOPLES]);
    },
    ...options,
  });

  return result;
};

