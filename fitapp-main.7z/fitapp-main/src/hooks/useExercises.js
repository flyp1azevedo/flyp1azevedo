import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { KEYS } from "../constants";
import {
  getExercises,
  createExercise,
  updateExercise,
  deleteExercise,
} from "services/api";

export const useGetExercises = (options = {}) => {
  const result = useQuery({
    queryKey: [KEYS.EXERCISES],
    queryFn: getExercises,
    ...options,
  });

  return result;
};

export const useCreateExercise = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: ({ data }) => createExercise(data),
    onSuccess: () => {
      query.invalidateQueries([KEYS.EXERCISES]);
    },
    ...options,
  });

  return result;
};

export const useUpdateExercise = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: ({ id, data }) => updateExercise(id, data),
    onSuccess: () => {
      query.invalidateQueries([KEYS.EXERCISES]);
    },
    ...options,
  });

  return result;
};

export const useDeleteExercise = (options = {}) => {
  const query = useQueryClient();

  const result = useMutation({
    mutationFn: (id) => deleteExercise(id),
    onSuccess: () => {
      query.invalidateQueries([KEYS.EXERCISES]);
    },
    ...options,
  });

  return result;
};
